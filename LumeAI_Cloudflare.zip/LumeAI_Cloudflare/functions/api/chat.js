const SYSTEM_PROMPT =
  "Ti chiami Lume. Sei un assistente AI utile, chiaro e creativo. " +
  "Rispondi in italiano, salvo diversa richiesta dell'utente.";

function json(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      "Content-Type": "application/json; charset=utf-8",
      "Cache-Control": "no-store",
      "X-Content-Type-Options": "nosniff"
    }
  });
}

export async function onRequestPost({ request, env }) {
  // Accetta richieste same-origin; impedisce chiamate cross-origin semplici.
  const origin = request.headers.get("Origin");
  if (origin) {
    try {
      if (new URL(origin).host !== new URL(request.url).host) {
        return json({ error: "Origine della richiesta non consentita." }, 403);
      }
    } catch {
      return json({ error: "Header Origin non valido." }, 403);
    }
  }

  if (!env.OPENAI_API_KEY) {
    return json({ error: "Il server non è configurato: manca il secret OPENAI_API_KEY." }, 500);
  }

  const contentType = request.headers.get("Content-Type") || "";
  if (!contentType.toLowerCase().includes("application/json")) {
    return json({ error: "La richiesta deve essere JSON." }, 415);
  }

  let body;
  try {
    body = await request.json();
  } catch {
    return json({ error: "Corpo JSON non valido." }, 400);
  }

  if (!Array.isArray(body.messages) || body.messages.length === 0) {
    return json({ error: "Nessun messaggio ricevuto." }, 400);
  }

  // Limita contesto, ruoli e lunghezza per ridurre abusi e costi.
  const messages = body.messages.slice(-12);
  const input = [];
  for (const item of messages) {
    if (!item || !["user", "assistant"].includes(item.role) ||
        typeof item.content !== "string") {
      return json({ error: "Formato della conversazione non valido." }, 400);
    }
    const content = item.content.trim();
    if (!content || content.length > 10000) {
      return json({ error: "Un messaggio è vuoto o troppo lungo." }, 400);
    }
    input.push({ role: item.role, content });
  }

  if (input[input.length - 1]?.role !== "user") {
    return json({ error: "L'ultimo messaggio deve essere dell'utente." }, 400);
  }

  try {
    const apiResponse = await fetch("https://api.openai.com/v1/responses", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${env.OPENAI_API_KEY}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        model: "gpt-4.1-mini",
        instructions: SYSTEM_PROMPT,
        input,
        max_output_tokens: 1200,
        store: false
      })
    });

    const result = await apiResponse.json().catch(() => ({}));

    if (!apiResponse.ok) {
      // Non restituire al browser dettagli interni o la risposta grezza del provider.
      console.error("OpenAI API error:", apiResponse.status, result?.error?.code || result?.error?.type || "unknown");
      if (apiResponse.status === 401) {
        return json({ error: "Chiave API non valida. Controlla il secret su Cloudflare." }, 502);
      }
      if (apiResponse.status === 429) {
        return json({ error: "Limite API raggiunto o credito API insufficiente. Controlla il tuo account OpenAI." }, 429);
      }
      return json({ error: "Il servizio AI non è riuscito a elaborare la richiesta." }, 502);
    }

    let reply = typeof result.output_text === "string" ? result.output_text : "";
    if (!reply && Array.isArray(result.output)) {
      reply = result.output.flatMap(item =>
        Array.isArray(item.content) ? item.content : []
      ).filter(part => part.type === "output_text" && typeof part.text === "string")
       .map(part => part.text).join("\n");
    }
    if (!reply.trim()) {
      return json({ error: "Il modello non ha restituito una risposta testuale." }, 502);
    }

    return json({ reply: reply.trim() });
  } catch (error) {
    console.error("Request to OpenAI failed:", error?.message || "unknown error");
    return json({ error: "Impossibile raggiungere il servizio AI. Riprova tra poco." }, 502);
  }
}

export async function onRequest(context) {
  if (context.request.method === "OPTIONS") {
    return new Response(null, {
      status: 204,
      headers: { "Allow": "POST, OPTIONS" }
    });
  }
  return json({ error: "Metodo non consentito." }, 405);
}
