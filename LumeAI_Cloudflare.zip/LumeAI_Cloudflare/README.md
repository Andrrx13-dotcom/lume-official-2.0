# Lume AI — Cloudflare Pages + Functions

Questo progetto contiene:
- `public/index.html`: frontend in un unico file HTML, con stile Lume e chat.
- `functions/api/chat.js`: endpoint serverless `/api/chat` che chiama la OpenAI Responses API.
- `wrangler.toml`: configurazione minima per Cloudflare Pages.

## Prima di pubblicare

1. Crea un account Cloudflare e un account OpenAI API. L'API viene fatturata separatamente dall'abbonamento ChatGPT.
2. Crea una API key in https://platform.openai.com/api-keys.
3. NON inserire la chiave in `index.html`, in `wrangler.toml`, in un repository Git o in un file pubblico.

## Pubblicazione consigliata: Git + Cloudflare Pages

Pages Functions non vengono eseguite se carichi solo il file HTML con un semplice hosting statico. Pubblica l'intero progetto via Git oppure con Wrangler.

1. Estrai la cartella ZIP.
2. Rinomina `public` in `dist` (oppure modifica `pages_build_output_dir` in `wrangler.toml` a `./public`; il file `index.html` deve rimanere dentro quella cartella).
3. Crea un repository Git e carica i file `functions/`, `dist/` e `wrangler.toml`.
4. In Cloudflare Dashboard, vai su Workers & Pages → Create → Pages → Connect to Git e seleziona il repository.
5. Configura:
   - Build command: lascia vuoto se richiesto/consentito.
   - Build output directory: `dist`.
6. Nel progetto Pages vai in Settings → Variables and Secrets (o Settings → Bindings → Variables and Secrets, la voce può variare) → Add → Secret.
7. Nome: `OPENAI_API_KEY`; valore: la tua chiave API OpenAI. Salva come secret cifrato.
8. Avvia un nuovo deployment dopo aver aggiunto il secret.
9. Apri il dominio Pages assegnato da Cloudflare e prova a inviare un messaggio.

## Pubblicazione con Wrangler da terminale

Prerequisiti: Node.js e account Cloudflare.

1. Nella cartella del progetto, installa Wrangler:
   `npm install -D wrangler`
2. Se usi `public` come cartella statica, aggiorna `pages_build_output_dir` nel `wrangler.toml` da `./dist` a `./public`.
3. Accedi a Cloudflare:
   `npx wrangler login`
4. Pubblica (se hai già creato un progetto Pages con nome `lume-ai`):
   `npx wrangler pages deploy public --project-name=lume-ai`
5. Configura il secret per il progetto Pages con:
   `npx wrangler pages secret put OPENAI_API_KEY --project-name=lume-ai`
   Quando richiesto, incolla la chiave nel terminale. Non metterla in un comando condiviso, screenshot o file di codice.
6. Se necessario, esegui nuovamente il deployment dopo aver configurato il secret.

Nota: i comandi e le schermate Cloudflare possono cambiare. Se usi Wrangler, assicurati che il progetto Pages esista e che la configurazione sia coerente con il nome e la cartella di output.

## Test locale

Installa Wrangler nella cartella:
`npm install -D wrangler`

Per testare Pages localmente, usa:
`npx wrangler pages dev public`

Per i secrets locali, crea un file `.dev.vars` nella radice del progetto:
`OPENAI_API_KEY="la-tua-chiave"`

Non caricare `.dev.vars` su Git. Cancella il file quando non serve più. Per il test locale, verifica che la tua versione di Wrangler carichi i secrets locali per Pages Functions.

## Sicurezza e limiti

- La chiave API resta nel secret Cloudflare e non viene inviata al browser.
- La funzione limita lunghezza e numero di messaggi, ma non include autenticazione, CAPTCHA o rate limiting persistente. Se rendi il sito pubblico, aggiungi protezione contro abusi e spese API inattese (ad esempio Cloudflare Turnstile, rate limiting o autenticazione).
- `store: false` chiede alla Responses API di non memorizzare la risposta come oggetto di conversazione; consulta comunque la documentazione OpenAI per le condizioni applicabili.
- Il modello impostato è `gpt-4.1-mini`. Se non è disponibile per il tuo progetto API, cambia `model` in `functions/api/chat.js` con un modello abilitato nel tuo account.
- Learn & Earn e piani sono soltanto demo visive: non eseguono pagamenti e i crediti demo non hanno valore monetario.
